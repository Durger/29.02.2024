import java.lang.annotation.*;

//@interface CodeAuthor {
//  String name();
//    int version() default  1;
//    String edited () default "01/01/1970";
//    String[] asisstants();
//}

/*@interface CodeAuthor {
  String name();
    int version() default();
    String edited () default ();
    String[] asisstants();
}*/
@Inherited//можно пользоваться в классах наследниках класса над которым обращаемся к анотации
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@interface Company{
    String name () default  "a, b, c";
    String city () default  "x, y, z";

}
@Company
class CustumAnnotationEmploye{
    int id;
    String name;

    public CustumAnnotationEmploye(int id, String name){
        this.id = id;
        this.name = name;
    }
    public void getEmployeDetalis (){
        System.out.println("Employe id: " + id);
        System.out.println("Employe name: " + name);
    }
}

class CustumAnnotationManager extends  CustumAnnotationEmploye{

    public CustumAnnotationManager(int id, String name) {
        super(id, name);
    }
}


public class Main {
    public static void main(String[] args) {



       /* @CodeAuthor (name = "Indiana Jones", version = 1, edited = "01/01/1970", asisstants = {"Marion",
                "Sallar"}
        )
                class LostArk{
            //class members
        }*/


        /*@CodeAuthor (name = "Indiana Jones", asisstants = {"Marion",
                "Sallar"}
        )
        class LostArk{

            }
            //class members
        }
*/

        CustumAnnotationEmploye custumAnnotationEmploye = new CustumAnnotationEmploye(1,"Jones");
        custumAnnotationEmploye.getEmployeDetalis();
        Annotation companyAnatation = custumAnnotationEmploye.getClass().getAnnotation(Company.class);
        Company company = (Company) companyAnatation;
        System.out.println("Company name: " + company.name());
        System.out.println("Company city: " + company.city());


        CustumAnnotationManager custumAnnotationManager = new CustumAnnotationManager(2,"Jack");
        custumAnnotationManager.getEmployeDetalis();
        Annotation companyAnatation2 = custumAnnotationManager.getClass().getAnnotation(Company.class);
        Company company2 = (Company) companyAnatation2;
        System.out.println("Company name: " + company2.name());
        System.out.println("Company city: " + company2.city());
    }
}
/*

@Entity
class  Picture {
    @PrimaryKey
    protected  Integer pictureId;
    @Persistent
    protected  String pictureName = null;
    @Getter
    public String getPicture(){
        return this.pictureName;
    }
    @Setter
    public void setPictureName (@Optional pictureName){
        this.pictureName = pictureName;
    }
}*/

//Задача
//Создать анотацию, в которой должно быть 2 значения по умолчанию и эти значения должны быть числовым
//Создайте класс с этой анотацией в классе с функцией, которая принимает 2 целых числа и складывает их с числом объетом этого класса
//и умножает на число из поля этого класса.
//Дочерний класс, который будет с функцией делением суммы чисел вместо умножения

