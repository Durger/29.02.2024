import java.util.*;

public class Main {
    public static void main(String[] args) {
       /* HashSet <Fish> fishes = new HashSet<Fish>();
        fishes.add(new Fish ("ell", 1.5, 120));
        fishes.add(new Fish ("salmon", 2.5, 180));
        fishes.add(new Fish ("carp", 3.5, 80));
        fishes.add(new Fish ("trout", 2.2, 150));
        fishes.add(new Fish ("trout", 2.2, 150));

        System.out.println("Collection: " + fishes);
        System.out.println("Collection,s size: " + fishes.size());*/

        /*HashSet <String> countryHashSet = new HashSet<>();
        countryHashSet.add("Russia");
        countryHashSet.add("France");
        countryHashSet.add("Ganduras");
        countryHashSet.add("Kod Devuar");

        Iterator <String> iterator =  countryHashSet.iterator();
        while (iterator.hasNext()) {
            System.out.print("Сountry: " + iterator.next() + ", ");
        }
        System.out.println();
        System.out.println("Size of collections: " + countryHashSet.size());*/

//        Random random = new Random(30);
//        Set<Integer> integerSet = new HashSet<>();
//        for (int i = 0; i < 10; i++) {
//            integerSet.add(random.nextInt(100));
//            System.out.println(integerSet);}


        //Сортировка через TreeSet
           /* Random random2 = new Random(30);
            Set<Integer> integerSet2 = new TreeSet<>();
            for (int i = 0; i < 10; i++) {
                integerSet2.add(random2.nextInt(100));
                System.out.println(integerSet2);*/

       //Сортировка через TreeSet
       /* SortedSet <String> countrySet = new TreeSet<>();
        countrySet.add("Russia");
        countrySet.add("France");
        countrySet.add("Ganduras");
        countrySet.add("Kod Devuar");
        System.out.println(countrySet);*/

        SortedSet <String> animalSet = new TreeSet<>();
        animalSet.add ("Antiloop");
        animalSet.add ("Fox");
        animalSet.add ("Dog");
        animalSet.add ("Goat");
        animalSet.add ("Elephant");
        animalSet.add ("Bear");
        animalSet.add ("Hippo");
        animalSet.add ("Cat");

        Iterator iterator = animalSet.iterator();
        while (iterator.hasNext()){
            System.out.println(iterator.next() + " ");
        }
        System.out.println();
        System.out.println(animalSet.subSet("Dog", "Hippo"));    //диапазон от и до
        System.out.println(animalSet.tailSet("Dog")); //от элемента и до
        System.out.println(animalSet.headSet("Dog"));   // до элемента
        System.out.println(animalSet.first());                   //первый элемент
        System.out.println(animalSet.last());                    //последний элемент

            }

        }


    class Fish {
        private String name;
        private double weight;
        private double price;

        public Fish(String name, double weight, double price) {
            this.name = name;
            this.weight = weight;
            this.price = price;
        }

        @Override
        public String toString() {
            return this.name + " weight:" + this.weight + " price:" + this.price;
        }

        @Override
        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (obj instanceof Fish) {
                return false;
            }
            Fish tmp = (Fish) obj;
            return (tmp.name.equals(this.name) && tmp.weight == this.weight && tmp.price == (this.price));
        }

        public int hashCode() {
            int code = 17;
            code = 31 * code + this.name.hashCode();
            code = 31 * code + (int) this.weight;
            code = 31 * code + (int) this.price;
            return code;
        }

    }

