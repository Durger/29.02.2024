import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Main {
    public static void main(String[] args) {

        //Пример.1.
        /*List<Integer> items =new ArrayList<>();
        items.add(11);
        items.add(5);
        items.add(102);
        items.add(12);
        items.add(234);
        items.add(909);
        items.forEach(item->System.out.println(item));
        items.forEach(item->{
            if(item>100){
                int index =items.indexOf(item);
                items.set(index,item/10);
            }
        });
        System.out.println("После: ");
        items.forEach(item->System.out.println(item));

        List <Integer> squares = items.stream().map((i) -> i*i).collect(Collectors.toList())
        System.out.println("В квадрате");
        squares.forEach(item -> System.out.println(item));
        System.out.println("До квадрата:");
        items.forEach(item->System.out.println(item));*/




        //Пример.2.
        List <Fish> fishes = new ArrayList<>();
        fishes.add(new Fish("eel",1.5,120));
        fishes.add(new Fish("salmon",2.5,180));
        fishes.add(new Fish("carp",3.5,80));
        fishes.add(new Fish("tuna",4.2,320));
        fishes.add(new Fish("trout",2.8,150));

        //Суммирование :: -ссылка
        double coast1 = fishes.stream().filter(f -> f.getPrice() > 100).mapToDouble(Fish::getPrice).sum();
        System.out.println("Cost1: " + coast1);
        fishes.forEach(System.out::println);

        IntStream.of(1,2,3,4,5,6,8,9).forEach((c) -> System.out.println(c));


        //скидка 10%
        fishes.forEach(f -> System.out.println(f));
        fishes.stream().filter(f -> f.getPrice() > 100).forEach(f -> f.setPrice(f.getPrice() * 0.9));
        System.out.println("После: ");
        fishes.forEach(f -> System.out.println(f));

        //все больше 100
        List <Fish> selected = fishes.stream().filter(fish -> fish.getPrice() > 100).collect(Collectors.toList());
        System.out.println("После: ");
        selected.forEach(f -> System.out.println(f));

        //Подсчет и суммирование
        int number = (int) fishes.stream().filter(f->f.getPrice() > 100).count();
        double cost = fishes.stream().filter(f -> f.getPrice() > 100).mapToDouble(f -> f.getPrice()).sum();
        System.out.println("Count: " + number + "Cost: " + cost);

        //Фильтр
       /* Stream.of("Argentina","Bulgary","Canada", "Denmark", "Russia", "USA").filter((c)->c.startsWith("U")).forEach(c -> System.out.println(c));*/

        //Перевод всех значений к написанию в верхнем регистре - заглавые буквы
       /* Stream.of("Argentina","Bulgary","Canada", "Denmark", "Russia", "USA").map(String :: toUpperCase).forEach(c -> System.out.println(c));*/




    }
}

//Пример.2.2я часть
class Fish
{
    private String name;
    private double weight;
    private double price;

    public Fish(String name, double weight, double price)
    {
        this.name=name;
        this.weight=weight;
        this.price=price;
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        if (!(o instanceof Fish))
        {
            return false;
        }
        Fish tmp = (Fish) o;
        return (tmp.name.equals(this.name) &&
                tmp.weight == this.weight &&
                tmp.price == (this.price));
    }

    public int hashCode()
    {
        return this.name.hashCode();
    }

    public double getPrice(){
        return this.price;
    }
    public void setPrice (double price){
       this.price = price;
    }

    public double getWeight()
    {
        return this.weight;
    }

    @Override
    public String toString() {
        return this.name+" weight:"+this.weight + "price:"+this.price;
    }
}